import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Calendar,
  CheckCircle,
  AlertCircle,
  Clock,
  Search,
  Plus,
  DollarSign,
  Trash2,
  User,
  Phone,
  X,
  TrendingUp,
  History,
  FileText,
  ArrowDownLeft,
  ArrowUpRight,
  Building,
  RefreshCw,
} from 'lucide-react';
import toast from 'react-hot-toast';
import { useLanguage } from '../i18n';
import { convertToLanguage } from '../utils/transliterate';

interface Customer {
  _id: string;
  fullName: string;
  phone?: string;
  currentDebt: number;
  debtLimit?: number;
  debtDueDate?: string;
  createdAt: string;
  addedBy?: string;
  lastDebtDate?: string;
  debtLogId?: string; // Kassir rejimida qarz log ID
}

interface MyDebt {
  _id: string;
  creditorName: string;
  creditorPhone?: string;
  amount: number;
  paidAmount: number;
  remainingAmount: number;
  dueDate?: string;
  notes?: string;
  createdAt: string;
  type: 'supplier' | 'person' | 'other';
}

interface DebtStats {
  pending: number;
  todayDue: number;
  paid: number;
  overdue: number;
  total: number;
}

const Debts: React.FC = () => {
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'receivable' | 'payable'>('receivable');
  
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [allCustomers, setAllCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'pending' | 'overdue' | 'today'>('all');
  const [stats, setStats] = useState<DebtStats>({ pending: 0, todayDue: 0, paid: 0, overdue: 0, total: 0 });
  
  const [myDebts, setMyDebts] = useState<MyDebt[]>([]);
  const [myDebtsLoading, setMyDebtsLoading] = useState(false);
  const [myDebtsStats, setMyDebtsStats] = useState<DebtStats>({ pending: 0, todayDue: 0, paid: 0, overdue: 0, total: 0 });
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPayModal, setShowPayModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showAddMyDebtModal, setShowAddMyDebtModal] = useState(false);
  const [showPayMyDebtModal, setShowPayMyDebtModal] = useState(false);
  
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedMyDebt, setSelectedMyDebt] = useState<MyDebt | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [debtHistory, setDebtHistory] = useState<any[]>([]);
  const [form, setForm] = useState({ customerId: '', amountUsd: '', amountUzs: '', dueDate: '', notes: '' });
  const [newCustomerMode, setNewCustomerMode] = useState(false);
  const [newCustomerForm, setNewCustomerForm] = useState({ fullName: '', phone: '' });
  const [customerSearch, setCustomerSearch] = useState('');
  // Kafil (Guarantor) form
  const [guarantorForm, setGuarantorForm] = useState({ fullName: '', phone: '', address: '' });
  const [showGuarantorSection, setShowGuarantorSection] = useState(false);
  // Bo'lib to'lash (Installment) form
  const [isInstallment, setIsInstallment] = useState(false);
  const [installmentCount, setInstallmentCount] = useState(2);
  const [myDebtForm, setMyDebtForm] = useState({
    creditorName: '',
    creditorPhone: '',
    amountUsd: '',
    amountUzs: '',
    dueDate: '',
    notes: '',
    type: 'supplier' as 'supplier' | 'person' | 'other',
  });

  // Currency exchange rate
  const [usdRate, setUsdRate] = useState(12500);
  const [rateLoading, setRateLoading] = useState(false);

  // CBU API'dan valyuta kursini olish
  const fetchExchangeRate = async () => {
    setRateLoading(true);
    try {
      const response = await fetch('https://cbu.uz/uz/arkhiv-kursov-valyut/json/');
      const data = await response.json();
      const usdCurrency = data.find((item: any) => item.Ccy === 'USD');
      if (usdCurrency) {
        const rate = parseFloat(usdCurrency.Rate);
        setUsdRate(Math.round(rate));
      }
    } catch (error) {
      console.error('Valyuta kursini olishda xatolik:', error);
    } finally {
      setRateLoading(false);
    }
  };

  // USD o'zgarganda UZS ni hisoblash
  const handleAmountUsdChange = (value: string, formType: 'receivable' | 'payable') => {
    const usdValue = parseFloat(value) || 0;
    if (formType === 'receivable') {
      setForm({ ...form, amountUsd: value, amountUzs: usdValue ? Math.round(usdValue * usdRate).toString() : '' });
    } else {
      setMyDebtForm({ ...myDebtForm, amountUsd: value, amountUzs: usdValue ? Math.round(usdValue * usdRate).toString() : '' });
    }
  };

  // UZS o'zgarganda USD ni hisoblash
  const handleAmountUzsChange = (value: string, formType: 'receivable' | 'payable') => {
    const uzsValue = parseFloat(value) || 0;
    if (formType === 'receivable') {
      setForm({ ...form, amountUzs: value, amountUsd: uzsValue ? (uzsValue / usdRate).toFixed(2) : '' });
    } else {
      setMyDebtForm({ ...myDebtForm, amountUzs: value, amountUsd: uzsValue ? (uzsValue / usdRate).toFixed(2) : '' });
    }
  };

  const selectedCashier = JSON.parse(localStorage.getItem('selectedCashier') || '{}');
  const currentCashierId = selectedCashier?._id;

  useEffect(() => {
    fetchExchangeRate(); // CBU'dan valyuta kursini olish
    if (activeTab === 'receivable') {
      loadDebts();
      loadAllCustomers();
    } else {
      loadMyDebts();
    }
  }, [activeTab]);

  const loadDebts = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('accessToken');
      const url = currentCashierId 
        ? `/api/customers/debts/by-cashier/${currentCashierId}`
        : '/api/customers/debts/all';
      
      console.log('Loading debts from:', url);
      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      console.log('Debts response:', data);
      if (data.success) {
        if (currentCashierId && data.data) {
          const customerMap = new Map<string, Customer>();
          data.data.forEach((debt: any) => {
            const customerId = debt.customerId?.toString() || debt.customerId;
            const existing = customerMap.get(customerId);
            if (existing) {
              existing.currentDebt += debt.amount;
            } else {
              customerMap.set(customerId, {
                _id: customerId,
                fullName: debt.customerName,
                phone: debt.customerPhone,
                currentDebt: debt.amount,
                debtDueDate: debt.dueDate,
                createdAt: debt.createdAt,
                addedBy: selectedCashier?.fullName || 'Kassir',
              });
            }
          });
          const customersArray = Array.from(customerMap.values());
          setCustomers(customersArray);
          calculateStats(customersArray);
        } else {
          // Admin panel - to'g'ridan-to'g'ri customer ma'lumotlari
          const customersWithStringId = (data.data || []).map((c: any) => ({
            ...c,
            _id: c._id?.toString() || c._id,
          }));
          console.log('Customers with string ID:', customersWithStringId);
          setCustomers(customersWithStringId);
          calculateStats(customersWithStringId);
        }
      }
    } catch (error) {
      console.error('Load debts error:', error);
      toast.error(t('errors.loadError'));
    } finally {
      setLoading(false);
    }
  };

  const loadAllCustomers = async () => {
    try {
      const token = localStorage.getItem('accessToken');
      const response = await fetch('/api/customers', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      if (data.success) setAllCustomers(data.data || []);
    } catch (error) {
      console.error('Load customers error:', error);
    }
  };

  const calculateStats = (data: Customer[]) => {
    let pending = 0, todayDue = 0, paid = 0, overdue = 0, total = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    data.forEach((c) => {
      total += c.currentDebt;
      if (c.currentDebt === 0) { paid++; return; }
      if (c.debtDueDate) {
        const dueDate = new Date(c.debtDueDate);
        dueDate.setHours(0, 0, 0, 0);
        if (dueDate < today) overdue++;
        else if (dueDate >= today && dueDate < tomorrow) todayDue++;
        else pending++;
      } else {
        pending++;
      }
    });
    setStats({ pending, todayDue, paid, overdue, total });
  };

  const loadMyDebts = async () => {
    setMyDebtsLoading(true);
    try {
      const token = localStorage.getItem('accessToken');
      const response = await fetch('/api/my-debts', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      if (data.success) {
        setMyDebts(data.data || []);
        calculateMyDebtsStats(data.data || []);
      } else {
        const saved = localStorage.getItem('myDebts');
        const debts = saved ? JSON.parse(saved) : [];
        setMyDebts(debts);
        calculateMyDebtsStats(debts);
      }
    } catch (error) {
      const saved = localStorage.getItem('myDebts');
      const debts = saved ? JSON.parse(saved) : [];
      setMyDebts(debts);
      calculateMyDebtsStats(debts);
    } finally {
      setMyDebtsLoading(false);
    }
  };

  const calculateMyDebtsStats = (data: MyDebt[]) => {
    let pending = 0, todayDue = 0, paid = 0, overdue = 0, total = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    data.forEach((d) => {
      total += d.remainingAmount;
      if (d.remainingAmount === 0) { paid++; return; }
      if (d.dueDate) {
        const dueDate = new Date(d.dueDate);
        dueDate.setHours(0, 0, 0, 0);
        if (dueDate < today) overdue++;
        else if (dueDate >= today && dueDate < tomorrow) todayDue++;
        else pending++;
      } else {
        pending++;
      }
    });
    setMyDebtsStats({ pending, todayDue, paid, overdue, total });
  };

  const handleAddMyDebt = async () => {
    if (!myDebtForm.creditorName || (!myDebtForm.amountUzs && !myDebtForm.amountUsd)) {
      toast.error(t('errors.requiredField'));
      return;
    }
    
    const finalAmount = parseFloat(myDebtForm.amountUzs) || 0;
    
    const newDebt: MyDebt = {
      _id: `debt_${Date.now()}`,
      creditorName: myDebtForm.creditorName,
      creditorPhone: myDebtForm.creditorPhone,
      amount: finalAmount,
      paidAmount: 0,
      remainingAmount: finalAmount,
      dueDate: myDebtForm.dueDate || undefined,
      notes: myDebtForm.notes,
      createdAt: new Date().toISOString(),
      type: myDebtForm.type,
    };

    try {
      const token = localStorage.getItem('accessToken');
      const response = await fetch('/api/my-debts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(newDebt),
      });
      const data = await response.json();
      if (data.success) {
        toast.success("Qarz qo'shildi");
        loadMyDebts();
      } else {
        const saved = localStorage.getItem('myDebts');
        const debts = saved ? JSON.parse(saved) : [];
        debts.push(newDebt);
        localStorage.setItem('myDebts', JSON.stringify(debts));
        setMyDebts(debts);
        calculateMyDebtsStats(debts);
        toast.success("Qarz qo'shildi");
      }
    } catch {
      const saved = localStorage.getItem('myDebts');
      const debts = saved ? JSON.parse(saved) : [];
      debts.push(newDebt);
      localStorage.setItem('myDebts', JSON.stringify(debts));
      setMyDebts(debts);
      calculateMyDebtsStats(debts);
      toast.success("Qarz qo'shildi");
    }
    
    setShowAddMyDebtModal(false);
    setMyDebtForm({ creditorName: '', creditorPhone: '', amountUsd: '', amountUzs: '', dueDate: '', notes: '', type: 'supplier' });
  };

  const handlePayMyDebt = async () => {
    if (!selectedMyDebt || !payAmount) return;
    
    const amount = parseFloat(payAmount);
    const updatedDebt = {
      ...selectedMyDebt,
      paidAmount: selectedMyDebt.paidAmount + amount,
      remainingAmount: selectedMyDebt.remainingAmount - amount,
    };

    const saved = localStorage.getItem('myDebts');
    const debts: MyDebt[] = saved ? JSON.parse(saved) : [];
    const idx = debts.findIndex(d => d._id === selectedMyDebt._id);
    if (idx !== -1) {
      debts[idx] = updatedDebt;
      localStorage.setItem('myDebts', JSON.stringify(debts));
    }
    
    setMyDebts(prev => prev.map(d => d._id === selectedMyDebt._id ? updatedDebt : d));
    calculateMyDebtsStats(myDebts.map(d => d._id === selectedMyDebt._id ? updatedDebt : d));
    
    toast.success("To'lov qabul qilindi");
    setShowPayMyDebtModal(false);
    setSelectedMyDebt(null);
    setPayAmount('');
  };

  const handleDeleteMyDebt = (debt: MyDebt) => {
    if (!window.confirm(`${debt.creditorName} - qarzni o'chirmoqchimisiz?`)) return;
    
    const saved = localStorage.getItem('myDebts');
    const debts: MyDebt[] = saved ? JSON.parse(saved) : [];
    const filtered = debts.filter(d => d._id !== debt._id);
    localStorage.setItem('myDebts', JSON.stringify(filtered));
    setMyDebts(filtered);
    calculateMyDebtsStats(filtered);
    toast.success("Qarz o'chirildi");
  };

  const getCustomerStatus = (customer: Customer): 'pending' | 'overdue' | 'today' | 'paid' => {
    if (customer.currentDebt === 0) return 'paid';
    if (!customer.debtDueDate) return 'pending';
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const dueDate = new Date(customer.debtDueDate);
    dueDate.setHours(0, 0, 0, 0);
    if (dueDate < today) return 'overdue';
    if (dueDate >= today && dueDate < tomorrow) return 'today';
    return 'pending';
  };

  const handleAddDebt = async () => {
    // Kafil ma'lumotlarini tayyorlash
    const guarantorData = showGuarantorSection && guarantorForm.fullName ? {
      fullName: guarantorForm.fullName,
      phone: guarantorForm.phone || undefined,
      address: guarantorForm.address || undefined,
    } : undefined;

    // Yangi mijoz qo'shish rejimi
    if (newCustomerMode) {
      if (!newCustomerForm.fullName || (!form.amountUzs && !form.amountUsd)) {
        toast.error(t('errors.requiredField'));
        return;
      }
      const finalAmount = parseFloat(form.amountUzs) || 0;
      try {
        const token = localStorage.getItem('accessToken');
        // Avval yangi mijoz yaratamiz
        const customerResponse = await fetch('/api/customers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({ 
            fullName: newCustomerForm.fullName, 
            phone: newCustomerForm.phone || undefined 
          }),
        });
        const customerData = await customerResponse.json();
        if (!customerData.success) {
          toast.error(customerData.message || t('common.error'));
          return;
        }
        const newCustomerId = customerData.data._id;
        
        // Keyin qarz qo'shamiz (kafil va bo'lib to'lash bilan)
        const response = await fetch(`/api/customers/${newCustomerId}/add-debt`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({ 
            amount: finalAmount, 
            dueDate: form.dueDate || undefined, 
            notes: form.notes || undefined,
            cashierId: currentCashierId || undefined,
            guarantor: guarantorData,
            isInstallment: isInstallment,
            installmentCount: isInstallment ? installmentCount : undefined,
          }),
        });
        const data = await response.json();
        if (data.success) {
          toast.success(t('debts.debtAdded'));
          setShowAddModal(false);
          setForm({ customerId: '', amountUsd: '', amountUzs: '', dueDate: '', notes: '' });
          setNewCustomerForm({ fullName: '', phone: '' });
          setGuarantorForm({ fullName: '', phone: '', address: '' });
          setShowGuarantorSection(false);
          setIsInstallment(false);
          setInstallmentCount(2);
          setNewCustomerMode(false);
          setCustomerSearch('');
          loadDebts();
          loadAllCustomers();
        } else {
          toast.error(data.message || t('common.error'));
        }
      } catch (error) {
        toast.error(t('errors.somethingWentWrong'));
      }
      return;
    }

    // Mavjud mijozga qarz qo'shish
    if (!form.customerId || (!form.amountUzs && !form.amountUsd)) {
      toast.error(t('errors.requiredField'));
      return;
    }
    const finalAmount = parseFloat(form.amountUzs) || 0;
    try {
      const token = localStorage.getItem('accessToken');
      const response = await fetch(`/api/customers/${form.customerId}/add-debt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ 
          amount: finalAmount, 
          dueDate: form.dueDate || undefined, 
          notes: form.notes || undefined,
          cashierId: currentCashierId || undefined,
          guarantor: guarantorData,
          isInstallment: isInstallment,
          installmentCount: isInstallment ? installmentCount : undefined,
        }),
      });
      const data = await response.json();
      if (data.success) {
        toast.success(t('debts.debtAdded'));
        setShowAddModal(false);
        setForm({ customerId: '', amountUsd: '', amountUzs: '', dueDate: '', notes: '' });
        setGuarantorForm({ fullName: '', phone: '', address: '' });
        setShowGuarantorSection(false);
        setIsInstallment(false);
        setInstallmentCount(2);
        setCustomerSearch('');
        loadDebts();
      } else {
        toast.error(data.message || t('common.error'));
      }
    } catch (error) {
      toast.error(t('errors.somethingWentWrong'));
    }
  };

  const handlePayDebt = async () => {
    if (!selectedCustomer || !payAmount) {
      toast.error(t('errors.requiredField'));
      return;
    }
    try {
      const token = localStorage.getItem('accessToken');
      const response = await fetch(`/api/customers/${selectedCustomer._id}/pay-debt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ amount: parseFloat(payAmount), cashierId: currentCashierId || undefined }),
      });
      const data = await response.json();
      if (data.success) {
        toast.success(t('debts.debtPaid'));
        setShowPayModal(false);
        setSelectedCustomer(null);
        setPayAmount('');
        loadDebts();
      } else {
        toast.error(data.message || t('common.error'));
      }
    } catch (error) {
      toast.error(t('errors.somethingWentWrong'));
    }
  };

  const handleDeleteDebt = async (customer: Customer) => {
    if (!window.confirm(`${customer.fullName} ${t('debts.confirmDelete')}`)) return;
    try {
      const token = localStorage.getItem('accessToken');
      console.log('Deleting debt for customer:', customer._id);
      const response = await fetch(`/api/customers/${customer._id}/delete-debt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ notes: t('debts.debtDeleted'), cashierId: currentCashierId || undefined }),
      });
      const data = await response.json();
      console.log('Delete response:', data);
      if (data.success) {
        toast.success(t('debts.debtDeleted'));
        loadDebts();
      } else {
        toast.error(data.message || t('common.error'));
      }
    } catch (error) {
      console.error('Delete debt error:', error);
      toast.error(t('errors.somethingWentWrong'));
    }
  };

  const loadDebtHistory = async (customer: Customer) => {
    try {
      const token = localStorage.getItem('accessToken');
      const response = await fetch(`/api/customers/${customer._id}/debt-history`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await response.json();
      if (data.success) setDebtHistory(data.data || []);
    } catch (error) {
      console.error('Load history error:', error);
    }
    setSelectedCustomer(customer);
    setShowHistoryModal(true);
  };

  const openPayModal = (customer: Customer) => {
    setSelectedCustomer(customer);
    setPayAmount('');
    setShowPayModal(true);
  };

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch = c.fullName.toLowerCase().includes(searchQuery.toLowerCase()) || (c.phone && c.phone.includes(searchQuery));
    if (activeFilter === 'all') return matchesSearch;
    return matchesSearch && getCustomerStatus(c) === activeFilter;
  });

  const filteredMyDebts = myDebts.filter((d) => {
    return d.creditorName.toLowerCase().includes(searchQuery.toLowerCase()) || 
           (d.creditorPhone && d.creditorPhone.includes(searchQuery));
  });

  const formatDate = (dateStr: string) => new Date(dateStr).toLocaleDateString('uz-UZ');
  const formatMoney = (amount: number) => amount.toLocaleString('uz-UZ');

  const getDaysRemaining = (dueDate?: string) => {
    if (!dueDate) return null;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);
    return Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  };

  const getStatusBadge = (customer: Customer) => {
    const status = getCustomerStatus(customer);
    const days = getDaysRemaining(customer.debtDueDate);
    switch (status) {
      case 'overdue':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-100 text-red-700 text-xs font-medium rounded-full">
            <AlertCircle className="w-3 h-3" />
            {days !== null ? `${Math.abs(days)} kun o'tgan` : "Muddati o'tgan"}
          </span>
        );
      case 'today':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-100 text-amber-700 text-xs font-medium rounded-full">
            <Clock className="w-3 h-3" />
            Bugun
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
            <Clock className="w-3 h-3" />
            {days !== null ? `${days} kun qoldi` : 'Kutilmoqda'}
          </span>
        );
    }
  };

  const getMyDebtStatus = (debt: MyDebt) => {
    if (debt.remainingAmount === 0) return 'paid';
    if (!debt.dueDate) return 'pending';
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDate = new Date(debt.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    if (dueDate < today) return 'overdue';
    return 'pending';
  };

  const currentStats = activeTab === 'receivable' ? stats : myDebtsStats;


  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-slate-50 via-gray-50 to-slate-100">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-xl border-b border-gray-200/50 px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          {/* Tabs */}
          <div className="flex bg-gray-100 rounded-xl p-1">
            <button
              onClick={() => setActiveTab('receivable')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'receivable'
                  ? 'bg-white text-cyan-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <ArrowDownLeft className="w-4 h-4" />
              Menga qarzdor
            </button>
            <button
              onClick={() => setActiveTab('payable')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'payable'
                  ? 'bg-white text-orange-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              Men qarzdorman
            </button>
          </div>

          {/* Search & Add */}
          <div className="flex-1 flex items-center gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                value={searchQuery} 
                onChange={(e) => setSearchQuery(e.target.value)} 
                placeholder="Qidirish..." 
                className="w-full pl-10 pr-4 py-2.5 bg-gray-100/80 border-0 rounded-xl text-sm focus:ring-2 focus:ring-cyan-500/50 focus:bg-white transition-all" 
              />
            </div>
            <button 
              onClick={() => activeTab === 'receivable' ? setShowAddModal(true) : setShowAddMyDebtModal(true)} 
              className="flex items-center gap-2 px-4 py-2.5 bg-cyan-500 hover:bg-cyan-600 text-white rounded-xl text-sm font-semibold transition-all shadow-lg shadow-cyan-500/25 hover:-translate-y-0.5"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Yangi qarz</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="px-4 sm:px-6 py-4">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 sm:gap-3">
          <div className="bg-white rounded-xl p-3 border border-gray-200/60">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-blue-100 rounded-lg">
                <Clock className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">Kutilmoqda</p>
                <p className="text-lg font-bold text-gray-900">{currentStats.pending}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-3 border border-gray-200/60">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-amber-100 rounded-lg">
                <Calendar className="w-4 h-4 text-amber-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">Bugun to'lanadigan</p>
                <p className="text-lg font-bold text-gray-900">{currentStats.todayDue}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-3 border border-gray-200/60">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-emerald-100 rounded-lg">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">To'langan</p>
                <p className="text-lg font-bold text-gray-900">{currentStats.paid}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-3 border border-gray-200/60">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-red-100 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500">Muddati o'tgan</p>
                <p className="text-lg font-bold text-gray-900">{currentStats.overdue}</p>
              </div>
            </div>
          </div>
          <div className={`rounded-xl p-3 col-span-2 sm:col-span-1 ${activeTab === 'receivable' ? 'bg-gradient-to-br from-cyan-500 to-teal-600' : 'bg-gradient-to-br from-orange-500 to-amber-600'}`}>
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-white/20 rounded-lg">
                <TrendingUp className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-xs text-white/80">Jami qarz</p>
                <p className="text-lg font-bold text-white">{formatMoney(currentStats.total)} so'm</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-4 sm:px-6 pb-6 overflow-auto">
        <div className="bg-white rounded-2xl border border-gray-200/60 overflow-hidden shadow-sm">
          {/* MENGA QARZDOR TAB */}
          {activeTab === 'receivable' && (
            <>
              {loading ? (
                <div className="flex flex-col items-center justify-center py-20">
                  <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : filteredCustomers.length === 0 ? (
                <div className="text-center py-20">
                  <div className="w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <CreditCard className="w-10 h-10 text-gray-300" />
                  </div>
                  <p className="text-gray-500 font-medium">Qarzlar topilmadi</p>
                  <p className="text-gray-400 text-sm mt-1">Hozircha qarzlar yo'q</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {filteredCustomers.map((customer) => {
                    const status = getCustomerStatus(customer);
                    return (
                      <div key={customer._id} className={`p-4 hover:bg-gray-50 ${status === 'overdue' ? 'bg-red-50/30' : ''}`}>
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                            status === 'overdue' ? 'bg-gradient-to-br from-red-400 to-red-500' : 
                            status === 'today' ? 'bg-gradient-to-br from-amber-400 to-orange-500' : 
                            'bg-gradient-to-br from-cyan-400 to-teal-500'
                          }`}>
                            <User className="w-5 h-5 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-gray-900">{convertToLanguage(customer.fullName, language)}</p>
                            {customer.phone && (
                              <p className="text-xs text-gray-500 flex items-center gap-1">
                                <Phone className="w-3 h-3" />{customer.phone}
                              </p>
                            )}
                          </div>
                          <div className="text-right">
                            <p className={`text-lg font-bold ${status === 'overdue' ? 'text-red-600' : 'text-gray-900'}`}>
                              {formatMoney(customer.currentDebt)} so'm
                            </p>
                            {getStatusBadge(customer)}
                          </div>
                          <div className="flex items-center gap-1">
                            <button onClick={() => loadDebtHistory(customer)} className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg">
                              <History className="w-4 h-4" />
                            </button>
                            <button onClick={() => openPayModal(customer)} className="p-2 text-cyan-600 hover:bg-cyan-100 rounded-lg">
                              <DollarSign className="w-4 h-4" />
                            </button>
                            <button onClick={() => handleDeleteDebt(customer)} className="p-2 text-red-600 hover:bg-red-100 rounded-lg">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* MEN QARZDORMAN TAB */}
          {activeTab === 'payable' && (
            <>
              {myDebtsLoading ? (
                <div className="flex flex-col items-center justify-center py-20">
                  <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
                </div>
              ) : filteredMyDebts.length === 0 ? (
                <div className="text-center py-20">
                  <div className="w-20 h-20 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <ArrowUpRight className="w-10 h-10 text-gray-300" />
                  </div>
                  <p className="text-gray-500 font-medium">Qarzlar topilmadi</p>
                  <p className="text-gray-400 text-sm mt-1">Siz hech kimga qarzdor emassiz</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {filteredMyDebts.map((debt) => {
                    const status = getMyDebtStatus(debt);
                    return (
                      <div key={debt._id} className={`p-4 hover:bg-gray-50 ${status === 'overdue' ? 'bg-red-50/30' : ''}`}>
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                            debt.type === 'supplier' ? 'bg-gradient-to-br from-blue-400 to-indigo-500' :
                            debt.type === 'person' ? 'bg-gradient-to-br from-purple-400 to-violet-500' :
                            'bg-gradient-to-br from-gray-400 to-slate-500'
                          }`}>
                            {debt.type === 'supplier' ? <Building className="w-5 h-5 text-white" /> : <User className="w-5 h-5 text-white" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-gray-900">{debt.creditorName}</p>
                            {debt.creditorPhone && (
                              <p className="text-xs text-gray-500 flex items-center gap-1">
                                <Phone className="w-3 h-3" />{debt.creditorPhone}
                              </p>
                            )}
                          </div>
                          <div className="text-right">
                            <p className={`text-lg font-bold ${status === 'overdue' ? 'text-red-600' : 'text-gray-900'}`}>
                              {formatMoney(debt.remainingAmount)} so'm
                            </p>
                            <p className="text-xs text-gray-500">
                              {debt.paidAmount > 0 && `To'langan: ${formatMoney(debt.paidAmount)}`}
                            </p>
                            {debt.dueDate && (
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded-full mt-1 ${
                                status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                              }`}>
                                <Calendar className="w-3 h-3" />
                                {formatDate(debt.dueDate)}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1">
                            <button 
                              onClick={() => { setSelectedMyDebt(debt); setPayAmount(''); setShowPayMyDebtModal(true); }} 
                              className="p-2 text-cyan-600 hover:bg-cyan-100 rounded-lg"
                            >
                              <DollarSign className="w-4 h-4" />
                            </button>
                            <button onClick={() => handleDeleteMyDebt(debt)} className="p-2 text-red-600 hover:bg-red-100 rounded-lg">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        {debt.notes && (
                          <p className="mt-2 text-sm text-gray-500 pl-13">{debt.notes}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      </div>


      {/* ==================== MODALS ==================== */}
      
      {/* Pay Modal (Receivable) */}
      {showPayModal && selectedCustomer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl">
            <div className="p-6 flex justify-between items-center bg-gradient-to-r from-cyan-500 to-teal-600">
              <h3 className="text-xl font-bold text-white">Qarz to'lash</h3>
              <button onClick={() => setShowPayModal(false)} className="p-2 hover:bg-white/20 rounded-xl">
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
            <div className="p-6">
              <div className="text-center mb-6">
                <p className="font-semibold text-gray-900">{convertToLanguage(selectedCustomer.fullName, language)}</p>
                <p className="text-3xl font-bold text-red-600 mt-2">{formatMoney(selectedCustomer.currentDebt)} so'm</p>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">To'lov summasi</label>
                <input type="number" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} className="w-full px-4 py-4 bg-gray-50 border-0 rounded-xl text-center text-2xl font-bold focus:ring-2 focus:ring-cyan-500" placeholder="0" autoFocus />
              </div>
              <div className="flex gap-2 mt-4">
                <button onClick={() => setPayAmount(Math.floor(selectedCustomer.currentDebt / 2).toString())} className="flex-1 py-3 bg-gray-100 rounded-xl text-sm font-semibold hover:bg-gray-200">50%</button>
                <button onClick={() => setPayAmount(selectedCustomer.currentDebt.toString())} className="flex-1 py-3 bg-cyan-100 text-cyan-700 rounded-xl text-sm font-semibold hover:bg-cyan-200">Hammasi</button>
              </div>
            </div>
            <div className="p-6 bg-gray-50 flex gap-3">
              <button onClick={() => setShowPayModal(false)} className="flex-1 px-4 py-3 text-gray-700 bg-white rounded-xl font-semibold border border-gray-200">Bekor</button>
              <button onClick={handlePayDebt} className="flex-1 px-4 py-3 bg-gradient-to-r from-cyan-500 to-teal-600 text-white rounded-xl font-semibold">To'lash</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Modal (Receivable) */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 flex justify-between items-center bg-gradient-to-r from-cyan-500 to-teal-600">
              <h3 className="text-xl font-bold text-white">Yangi qarz qo'shish</h3>
              <button onClick={() => { setShowAddModal(false); setNewCustomerMode(false); setCustomerSearch(''); setGuarantorForm({ fullName: '', phone: '', address: '' }); setShowGuarantorSection(false); setIsInstallment(false); setInstallmentCount(2); }} className="p-2 hover:bg-white/20 rounded-xl">
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              {/* Mijoz tanlash yoki yangi qo'shish */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-semibold text-gray-700">Mijoz *</label>
                  <button
                    type="button"
                    onClick={() => {
                      setNewCustomerMode(!newCustomerMode);
                      setForm({ ...form, customerId: '' });
                      setCustomerSearch('');
                    }}
                    className={`text-xs font-medium px-3 py-1 rounded-lg transition-all ${
                      newCustomerMode 
                        ? 'bg-cyan-100 text-cyan-700' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {newCustomerMode ? 'Mavjud mijoz' : '+ Yangi mijoz'}
                  </button>
                </div>
                
                {newCustomerMode ? (
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={newCustomerForm.fullName}
                      onChange={(e) => setNewCustomerForm({ ...newCustomerForm, fullName: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500"
                      placeholder="Ism familiya *"
                    />
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-medium">+998</span>
                      <input
                        type="tel"
                        value={newCustomerForm.phone.replace('+998', '')}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '').slice(0, 9);
                          setNewCustomerForm({ ...newCustomerForm, phone: value ? `+998${value}` : '' });
                        }}
                        className="w-full pl-16 pr-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500"
                        placeholder="XX XXX XX XX"
                        maxLength={9}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {/* Qidiruv inputi */}
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        value={customerSearch}
                        onChange={(e) => setCustomerSearch(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500"
                        placeholder="Ism yoki telefon raqam bilan qidiring..."
                      />
                    </div>
                    {/* Filterlangan mijozlar ro'yxati */}
                    <div className="max-h-40 overflow-y-auto rounded-xl border border-gray-200">
                      {allCustomers
                        .filter(c => {
                          if (!customerSearch) return true;
                          const search = customerSearch.toLowerCase();
                          const phoneSearch = customerSearch.replace(/\D/g, '');
                          return c.fullName.toLowerCase().includes(search) || 
                                 (c.phone && c.phone.replace(/\D/g, '').includes(phoneSearch));
                        })
                        .map((c) => (
                          <div
                            key={c._id}
                            onClick={() => {
                              setForm({ ...form, customerId: c._id });
                              setCustomerSearch(c.fullName + (c.phone ? ` (${c.phone})` : ''));
                            }}
                            className={`px-4 py-3 cursor-pointer hover:bg-gray-50 border-b border-gray-100 last:border-b-0 ${
                              form.customerId === c._id ? 'bg-cyan-50' : ''
                            }`}
                          >
                            <p className="font-medium text-gray-900">{convertToLanguage(c.fullName, language)}</p>
                            {c.phone && <p className="text-xs text-gray-500">{c.phone}</p>}
                          </div>
                        ))}
                      {allCustomers.filter(c => {
                        if (!customerSearch) return true;
                        const search = customerSearch.toLowerCase();
                        const phoneSearch = customerSearch.replace(/\D/g, '');
                        return c.fullName.toLowerCase().includes(search) || 
                               (c.phone && c.phone.replace(/\D/g, '').includes(phoneSearch));
                      }).length === 0 && (
                        <div className="px-4 py-6 text-center text-gray-500 text-sm">
                          Mijoz topilmadi
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              {/* Currency Rate */}
              <div className="bg-blue-50 rounded-xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-blue-700">Kurs: 1 $ =</span>
                  <span className="text-xs text-blue-500">(CBU)</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={usdRate}
                    onChange={(e) => setUsdRate(parseFloat(e.target.value) || 12500)}
                    className="w-28 px-3 py-1.5 bg-white border border-blue-200 rounded-lg text-sm text-center font-semibold focus:ring-2 focus:ring-blue-500"
                  />
                  <span className="text-sm font-medium text-blue-700">UZS</span>
                  <button
                    type="button"
                    onClick={fetchExchangeRate}
                    disabled={rateLoading}
                    className="p-1.5 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50"
                    title="CBU'dan yangilash"
                  >
                    <RefreshCw className={`w-4 h-4 ${rateLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Qarz summasi *</label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="relative">
                    <input type="number" value={form.amountUsd} onChange={(e) => handleAmountUsdChange(e.target.value, 'receivable')} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500 pr-14" placeholder="0" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-gray-500">USD</span>
                  </div>
                  <div className="relative">
                    <input type="number" value={form.amountUzs} onChange={(e) => handleAmountUzsChange(e.target.value, 'receivable')} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500 pr-14" placeholder="0" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-gray-500">UZS</span>
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">To'lov muddati</label>
                <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Izoh</label>
                <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500 resize-none" rows={2} />
              </div>
              
              {/* Kafil (Guarantor) Section */}
              <div className="border-t border-gray-200 pt-4">
                <button
                  type="button"
                  onClick={() => setShowGuarantorSection(!showGuarantorSection)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                    showGuarantorSection 
                      ? 'bg-amber-50 border-2 border-amber-300' 
                      : 'bg-gray-50 border-2 border-dashed border-gray-300 hover:border-gray-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <User className={`w-4 h-4 ${showGuarantorSection ? 'text-amber-600' : 'text-gray-500'}`} />
                    <span className={`text-sm font-semibold ${showGuarantorSection ? 'text-amber-700' : 'text-gray-600'}`}>
                      Kafil qo'shish
                    </span>
                  </div>
                  <span className={`text-xs ${showGuarantorSection ? 'text-amber-600' : 'text-gray-400'}`}>
                    {showGuarantorSection ? 'Yopish' : 'Ixtiyoriy'}
                  </span>
                </button>
                
                {showGuarantorSection && (
                  <div className="mt-3 p-4 bg-amber-50/50 rounded-xl border border-amber-200 space-y-3">
                    <p className="text-xs text-amber-700 mb-2">
                      Kafil - qarz oluvchi to'lay olmasa, uning o'rniga to'laydigan shaxs
                    </p>
                    <div>
                      <label className="block text-xs font-semibold text-gray-600 mb-1">Kafil ism familiyasi *</label>
                      <input
                        type="text"
                        value={guarantorForm.fullName}
                        onChange={(e) => setGuarantorForm({ ...guarantorForm, fullName: e.target.value })}
                        className="w-full px-4 py-2.5 bg-white border border-amber-200 rounded-xl focus:ring-2 focus:ring-amber-500 text-sm"
                        placeholder="Ism familiya"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-600 mb-1">Telefon raqami</label>
                      <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-medium">+998</span>
                        <input
                          type="tel"
                          value={guarantorForm.phone.replace('+998', '')}
                          onChange={(e) => {
                            const value = e.target.value.replace(/\D/g, '').slice(0, 9);
                            setGuarantorForm({ ...guarantorForm, phone: value ? `+998${value}` : '' });
                          }}
                          className="w-full pl-16 pr-4 py-2.5 bg-white border border-amber-200 rounded-xl focus:ring-2 focus:ring-amber-500 text-sm"
                          placeholder="XX XXX XX XX"
                          maxLength={9}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-600 mb-1">Manzil</label>
                      <input
                        type="text"
                        value={guarantorForm.address}
                        onChange={(e) => setGuarantorForm({ ...guarantorForm, address: e.target.value })}
                        className="w-full px-4 py-2.5 bg-white border border-amber-200 rounded-xl focus:ring-2 focus:ring-amber-500 text-sm"
                        placeholder="Manzil (tuman, ko'cha, uy)"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Bo'lib to'lash (Installment) Section */}
              <div className="border-t border-gray-200 pt-4">
                <button
                  type="button"
                  onClick={() => setIsInstallment(!isInstallment)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                    isInstallment 
                      ? 'bg-purple-50 border-2 border-purple-300' 
                      : 'bg-gray-50 border-2 border-dashed border-gray-300 hover:border-gray-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Calendar className={`w-4 h-4 ${isInstallment ? 'text-purple-600' : 'text-gray-500'}`} />
                    <span className={`text-sm font-semibold ${isInstallment ? 'text-purple-700' : 'text-gray-600'}`}>
                      Bo'lib to'lash
                    </span>
                  </div>
                  <span className={`text-xs ${isInstallment ? 'text-purple-600' : 'text-gray-400'}`}>
                    {isInstallment ? 'Yopish' : 'Ixtiyoriy'}
                  </span>
                </button>
                
                {isInstallment && (
                  <div className="mt-3 p-4 bg-purple-50/50 rounded-xl border border-purple-200 space-y-3">
                    <p className="text-xs text-purple-700 mb-2">
                      Qarzni necha bo'lakka bo'lish kerak? Har bir bo'lak uchun to'lov sanasi qarz qo'shilgan kundan boshlab hisoblanadi.
                    </p>
                    <div>
                      <label className="block text-xs font-semibold text-gray-600 mb-2">Bo'laklar soni</label>
                      <input
                        type="number"
                        min="2"
                        max="36"
                        value={installmentCount}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || 2;
                          setInstallmentCount(Math.min(36, Math.max(2, val)));
                        }}
                        className="w-full px-4 py-3 bg-white border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-center text-lg font-bold"
                        placeholder="2"
                      />
                      <div className="flex gap-2 mt-2">
                        {[2, 3, 4, 6, 12].map((count) => (
                          <button
                            key={count}
                            type="button"
                            onClick={() => setInstallmentCount(count)}
                            className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-all ${
                              installmentCount === count
                                ? 'bg-purple-500 text-white'
                                : 'bg-white border border-purple-200 text-purple-700 hover:bg-purple-100'
                            }`}
                          >
                            {count} oy
                          </button>
                        ))}
                      </div>
                    </div>
                    {/* Bo'laklar preview */}
                    {form.amountUzs && parseFloat(form.amountUzs) > 0 && installmentCount >= 2 && (
                      <div className="mt-3 p-3 bg-white rounded-xl border border-purple-200">
                        <p className="text-xs font-semibold text-gray-600 mb-2">To'lov jadvali (bugundan boshlab):</p>
                        <div className="space-y-1.5 max-h-48 overflow-y-auto">
                          {Array.from({ length: installmentCount }).map((_, i) => {
                            const totalAmount = parseFloat(form.amountUzs) || 0;
                            const perInstallment = Math.ceil(totalAmount / installmentCount);
                            const isLast = i === installmentCount - 1;
                            const thisAmount = isLast ? totalAmount - (perInstallment * (installmentCount - 1)) : perInstallment;
                            // Bugungi sanadan boshlab har oy
                            const dueDate = new Date();
                            dueDate.setMonth(dueDate.getMonth() + i);
                            return (
                              <div key={i} className="flex justify-between items-center text-xs py-1.5 border-b border-gray-100 last:border-0">
                                <div className="flex items-center gap-2">
                                  <span className="w-6 h-6 bg-purple-100 text-purple-700 rounded-full flex items-center justify-center text-[10px] font-bold">
                                    {i + 1}
                                  </span>
                                  <span className="text-gray-600">{dueDate.toLocaleDateString('uz-UZ')}</span>
                                </div>
                                <span className="font-semibold text-purple-700">{thisAmount.toLocaleString()} so'm</span>
                              </div>
                            );
                          })}
                        </div>
                        <div className="mt-2 pt-2 border-t border-purple-200 flex justify-between">
                          <span className="text-xs font-semibold text-gray-600">Jami:</span>
                          <span className="text-sm font-bold text-purple-700">{parseFloat(form.amountUzs).toLocaleString()} so'm</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            <div className="p-6 bg-gray-50 flex gap-3">
              <button onClick={() => { setShowAddModal(false); setNewCustomerMode(false); setCustomerSearch(''); setGuarantorForm({ fullName: '', phone: '', address: '' }); setShowGuarantorSection(false); setIsInstallment(false); setInstallmentCount(2); }} className="flex-1 px-4 py-3 text-gray-700 bg-white rounded-xl font-semibold border border-gray-200">Bekor</button>
              <button onClick={handleAddDebt} className="flex-1 px-4 py-3 bg-gradient-to-r from-cyan-500 to-teal-600 text-white rounded-xl font-semibold">Qo'shish</button>
            </div>
          </div>
        </div>
      )}

      {/* Add My Debt Modal (Payable) */}
      {showAddMyDebtModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 flex justify-between items-center bg-gradient-to-r from-cyan-500 to-teal-600 sticky top-0">
              <h3 className="text-xl font-bold text-white">Mening qarzim</h3>
              <button onClick={() => setShowAddMyDebtModal(false)} className="p-2 hover:bg-white/20 rounded-xl">
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Qarz turi</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'supplier', label: "Ta'minotchi", icon: Building },
                    { id: 'person', label: 'Shaxs', icon: User },
                    { id: 'other', label: 'Boshqa', icon: FileText },
                  ].map((type) => (
                    <button
                      key={type.id}
                      onClick={() => setMyDebtForm({ ...myDebtForm, type: type.id as any })}
                      className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${
                        myDebtForm.type === type.id ? 'border-cyan-500 bg-cyan-50' : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <type.icon className={`w-5 h-5 ${myDebtForm.type === type.id ? 'text-cyan-600' : 'text-gray-500'}`} />
                      <span className={`text-xs font-medium ${myDebtForm.type === type.id ? 'text-cyan-600' : 'text-gray-600'}`}>{type.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {myDebtForm.type === 'supplier' ? "Ta'minotchi nomi" : myDebtForm.type === 'person' ? 'Ism familiya' : 'Nomi'} *
                </label>
                <input type="text" value={myDebtForm.creditorName} onChange={(e) => setMyDebtForm({ ...myDebtForm, creditorName: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500" placeholder="Kiriting..." />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Telefon</label>
                <input type="tel" value={myDebtForm.creditorPhone} onChange={(e) => setMyDebtForm({ ...myDebtForm, creditorPhone: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500" placeholder="+998..." />
              </div>
              {/* Currency Rate */}
              <div className="bg-blue-50 rounded-xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-blue-700">Kurs: 1 $ =</span>
                  <span className="text-xs text-blue-500">(CBU)</span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={usdRate}
                    onChange={(e) => setUsdRate(parseFloat(e.target.value) || 12500)}
                    className="w-28 px-3 py-1.5 bg-white border border-blue-200 rounded-lg text-sm text-center font-semibold focus:ring-2 focus:ring-blue-500"
                  />
                  <span className="text-sm font-medium text-blue-700">UZS</span>
                  <button
                    type="button"
                    onClick={fetchExchangeRate}
                    disabled={rateLoading}
                    className="p-1.5 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50"
                    title="CBU'dan yangilash"
                  >
                    <RefreshCw className={`w-4 h-4 ${rateLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Qarz summasi *</label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="relative">
                    <input type="number" value={myDebtForm.amountUsd} onChange={(e) => handleAmountUsdChange(e.target.value, 'payable')} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500 pr-14" placeholder="0" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-gray-500">USD</span>
                  </div>
                  <div className="relative">
                    <input type="number" value={myDebtForm.amountUzs} onChange={(e) => handleAmountUzsChange(e.target.value, 'payable')} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500 pr-14" placeholder="0" />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-gray-500">UZS</span>
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">To'lov muddati</label>
                <input type="date" value={myDebtForm.dueDate} onChange={(e) => setMyDebtForm({ ...myDebtForm, dueDate: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Izoh</label>
                <textarea value={myDebtForm.notes} onChange={(e) => setMyDebtForm({ ...myDebtForm, notes: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border-0 rounded-xl focus:ring-2 focus:ring-cyan-500 resize-none" rows={2} placeholder="Qarz haqida..." />
              </div>
            </div>
            <div className="p-6 bg-gray-50 flex gap-3 sticky bottom-0">
              <button onClick={() => setShowAddMyDebtModal(false)} className="flex-1 px-4 py-3 text-gray-700 bg-white rounded-xl font-semibold border border-gray-200">Bekor</button>
              <button onClick={handleAddMyDebt} className="flex-1 px-4 py-3 bg-gradient-to-r from-cyan-500 to-teal-600 text-white rounded-xl font-semibold">Qo'shish</button>
            </div>
          </div>
        </div>
      )}

      {/* Pay My Debt Modal (Payable) */}
      {showPayMyDebtModal && selectedMyDebt && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl">
            <div className="p-6 flex justify-between items-center bg-gradient-to-r from-cyan-500 to-teal-600">
              <h3 className="text-xl font-bold text-white">Qarz to'lash</h3>
              <button onClick={() => setShowPayMyDebtModal(false)} className="p-2 hover:bg-white/20 rounded-xl">
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
            <div className="p-6">
              <div className="text-center mb-6">
                <p className="font-semibold text-gray-900">{selectedMyDebt.creditorName}</p>
                <p className="text-3xl font-bold text-red-600 mt-2">{formatMoney(selectedMyDebt.remainingAmount)} so'm</p>
                <p className="text-sm text-gray-500">Qoldiq qarz</p>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">To'lov summasi</label>
                <input type="number" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} className="w-full px-4 py-4 bg-gray-50 border-0 rounded-xl text-center text-2xl font-bold focus:ring-2 focus:ring-cyan-500" placeholder="0" autoFocus />
              </div>
              <div className="flex gap-2 mt-4">
                <button onClick={() => setPayAmount(Math.floor(selectedMyDebt.remainingAmount / 2).toString())} className="flex-1 py-3 bg-gray-100 rounded-xl text-sm font-semibold hover:bg-gray-200">50%</button>
                <button onClick={() => setPayAmount(selectedMyDebt.remainingAmount.toString())} className="flex-1 py-3 bg-cyan-100 text-cyan-700 rounded-xl text-sm font-semibold hover:bg-cyan-200">Hammasi</button>
              </div>
            </div>
            <div className="p-6 bg-gray-50 flex gap-3">
              <button onClick={() => setShowPayMyDebtModal(false)} className="flex-1 px-4 py-3 text-gray-700 bg-white rounded-xl font-semibold border border-gray-200">Bekor</button>
              <button onClick={handlePayMyDebt} className="flex-1 px-4 py-3 bg-gradient-to-r from-cyan-500 to-teal-600 text-white rounded-xl font-semibold">To'lash</button>
            </div>
          </div>
        </div>
      )}

      {/* History Modal */}
      {showHistoryModal && selectedCustomer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl max-h-[80vh] flex flex-col">
            <div className="p-6 flex justify-between items-center bg-gradient-to-r from-slate-700 to-slate-800">
              <div>
                <h3 className="text-xl font-bold text-white">Qarz tarixi</h3>
                <p className="text-sm text-slate-300">{convertToLanguage(selectedCustomer.fullName, language)}</p>
              </div>
              <button onClick={() => setShowHistoryModal(false)} className="p-2 hover:bg-white/20 rounded-xl">
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6">
              {debtHistory.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Tarix topilmadi</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {debtHistory.map((item, index) => (
                    <div key={index} className={`p-4 rounded-2xl border ${item.type === 'payment' ? 'bg-emerald-50 border-emerald-200' : 'bg-red-50 border-red-200'}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <p className={`font-semibold ${item.type === 'payment' ? 'text-emerald-700' : 'text-red-700'}`}>
                            {item.type === 'payment' ? "To'lov" : "Qarz qo'shildi"}
                          </p>
                          <p className="text-sm text-gray-500 mt-1">{formatDate(item.createdAt)}</p>
                        </div>
                        <p className={`text-lg font-bold ${item.type === 'payment' ? 'text-emerald-600' : 'text-red-600'}`}>
                          {item.type === 'payment' ? '-' : '+'}{formatMoney(item.amount)} so'm
                        </p>
                      </div>
                      {item.notes && <p className="text-sm text-gray-500 mt-3 pt-3 border-t border-gray-200">{item.notes}</p>}
                      
                      {/* Bo'lib to'lash ma'lumotlari */}
                      {item.isInstallment && item.installments && item.installments.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-gray-200 bg-purple-50 -mx-4 px-4 py-3">
                          <p className="text-xs font-semibold text-purple-700 mb-2">
                            Bo'lib to'lash ({item.installmentCount} bo'lak):
                          </p>
                          <div className="space-y-1.5">
                            {item.installments.map((inst: any, idx: number) => (
                              <div key={idx} className="flex justify-between items-center text-xs py-1 border-b border-purple-100 last:border-0">
                                <div className="flex items-center gap-2">
                                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                                    inst.isPaid ? 'bg-emerald-500 text-white' : 'bg-purple-200 text-purple-700'
                                  }`}>
                                    {inst.isPaid ? '✓' : idx + 1}
                                  </span>
                                  <span className="text-gray-600">{new Date(inst.dueDate).toLocaleDateString('uz-UZ')}</span>
                                </div>
                                <span className={`font-semibold ${inst.isPaid ? 'text-emerald-600 line-through' : 'text-purple-700'}`}>
                                  {formatMoney(inst.amount)} so'm
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {/* Kafil ma'lumotlari */}
                      {item.guarantor && item.guarantor.fullName && (
                        <div className={`mt-3 pt-3 border-t border-gray-200 bg-amber-50 -mx-4 ${item.isInstallment ? '' : '-mb-4'} px-4 py-3 ${item.isInstallment ? '' : 'rounded-b-2xl'}`}>
                          <p className="text-xs font-semibold text-amber-700 mb-1">Kafil:</p>
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-amber-600" />
                            <span className="text-sm font-medium text-gray-800">{item.guarantor.fullName}</span>
                          </div>
                          {item.guarantor.phone && (
                            <div className="flex items-center gap-2 mt-1">
                              <Phone className="w-3 h-3 text-amber-600" />
                              <span className="text-xs text-gray-600">{item.guarantor.phone}</span>
                            </div>
                          )}
                          {item.guarantor.address && (
                            <p className="text-xs text-gray-600 mt-1 pl-6">{item.guarantor.address}</p>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="p-6 bg-gray-50">
              <button onClick={() => setShowHistoryModal(false)} className="w-full px-4 py-3 bg-white text-gray-700 rounded-xl font-semibold border border-gray-200">Yopish</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Debts;
