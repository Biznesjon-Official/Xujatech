/**
 * Warehouse Routes
 * Omborlar va ko'chirishlar uchun API endpointlari
 */

import express, { Response } from 'express';
import Joi from 'joi';
import { logger } from '../utils/logger';
import { authenticateToken, requireManager, AuthRequest } from '../middleware/auth';
import { asyncHandler } from '../middleware/errorHandler';

const router = express.Router();

// In-memory storage (production da MongoDB model ishlatiladi)
const warehouses: any[] = [];
const transfers: any[] = [];

// Validation schemas
const warehouseValidation = Joi.object({
  name: Joi.string().min(2).max(100).required(),
  code: Joi.string().min(2).max(20).required(),
  address: Joi.string().max(500),
  phone: Joi.string().max(20),
  managerId: Joi.string(),
  isMain: Joi.boolean().default(false)
});

const transferValidation = Joi.object({
  fromWarehouseId: Joi.string().required(),
  toWarehouseId: Joi.string().required(),
  items: Joi.array().items(Joi.object({
    productId: Joi.string().required(),
    quantity: Joi.number().integer().positive().required()
  })).min(1).required(),
  notes: Joi.string().max(500).allow('')
});

// ==================== WAREHOUSE CRUD ====================

// Get all warehouses
router.get('/', authenticateToken, asyncHandler(async (req: AuthRequest, res: Response) => {
  res.json({
    success: true,
    data: warehouses.filter(w => w.isActive)
  });
}));

// Create warehouse
router.post('/', authenticateToken, requireManager, asyncHandler(async (req: AuthRequest, res: Response) => {
  const { error, value } = warehouseValidation.validate(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      message: error.details[0].message
    });
  }

  const warehouse = {
    _id: `wh_${Date.now()}`,
    ...value,
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  warehouses.push(warehouse);
  logger.info(`Warehouse ${value.name} created by ${req.user!.username}`);

  res.status(201).json({
    success: true,
    message: 'Warehouse created successfully',
    data: { id: warehouse._id }
  });
}));

// Get warehouse by ID
router.get('/:id', authenticateToken, asyncHandler(async (req: AuthRequest, res: Response) => {
  const warehouse = warehouses.find(w => w._id === req.params.id);

  if (!warehouse) {
    return res.status(404).json({
      success: false,
      message: 'Warehouse not found'
    });
  }

  res.json({
    success: true,
    data: warehouse
  });
}));

// Update warehouse
router.put('/:id', authenticateToken, requireManager, asyncHandler(async (req: AuthRequest, res: Response) => {
  const { error, value } = warehouseValidation.validate(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      message: error.details[0].message
    });
  }

  const index = warehouses.findIndex(w => w._id === req.params.id);
  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: 'Warehouse not found'
    });
  }

  warehouses[index] = { ...warehouses[index], ...value, updatedAt: new Date() };

  res.json({
    success: true,
    message: 'Warehouse updated successfully',
    data: warehouses[index]
  });
}));

// Delete warehouse (soft delete)
router.delete('/:id', authenticateToken, requireManager, asyncHandler(async (req: AuthRequest, res: Response) => {
  const index = warehouses.findIndex(w => w._id === req.params.id);
  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: 'Warehouse not found'
    });
  }

  warehouses[index].isActive = false;

  res.json({
    success: true,
    message: 'Warehouse deleted successfully'
  });
}));

// ==================== TRANSFERS ====================

// Get all transfers
router.get('/transfers/list', authenticateToken, asyncHandler(async (req: AuthRequest, res: Response) => {
  const { status } = req.query;
  let result = transfers;
  
  if (status) {
    result = transfers.filter(t => t.status === status);
  }

  res.json({
    success: true,
    data: result
  });
}));

// Create transfer
router.post('/transfers', authenticateToken, requireManager, asyncHandler(async (req: AuthRequest, res: Response) => {
  const { error, value } = transferValidation.validate(req.body);
  if (error) {
    return res.status(400).json({
      success: false,
      message: error.details[0].message
    });
  }

  if (value.fromWarehouseId === value.toWarehouseId) {
    return res.status(400).json({
      success: false,
      message: 'Source and destination warehouses must be different'
    });
  }

  const transferNumber = `TRF${Date.now()}`;
  const transfer = {
    _id: `tr_${Date.now()}`,
    transferNumber,
    ...value,
    status: 'pending',
    createdBy: req.user!.id,
    createdAt: new Date()
  };

  transfers.push(transfer);
  logger.info(`Transfer ${transferNumber} created by ${req.user!.username}`);

  res.status(201).json({
    success: true,
    message: 'Transfer created successfully',
    data: { id: transfer._id, transferNumber }
  });
}));

// Approve transfer
router.post('/transfers/:id/approve', authenticateToken, requireManager, asyncHandler(async (req: AuthRequest, res: Response) => {
  const transfer = transfers.find(t => t._id === req.params.id);

  if (!transfer) {
    return res.status(404).json({
      success: false,
      message: 'Transfer not found'
    });
  }

  if (transfer.status !== 'pending') {
    return res.status(400).json({
      success: false,
      message: 'Transfer is not in pending status'
    });
  }

  transfer.status = 'completed';
  transfer.approvedBy = req.user!.id;
  transfer.approvedAt = new Date();
  transfer.completedAt = new Date();

  logger.info(`Transfer ${transfer.transferNumber} approved by ${req.user!.username}`);

  res.json({
    success: true,
    message: 'Transfer approved and completed successfully'
  });
}));

// Cancel transfer
router.post('/transfers/:id/cancel', authenticateToken, requireManager, asyncHandler(async (req: AuthRequest, res: Response) => {
  const transfer = transfers.find(t => t._id === req.params.id);

  if (!transfer) {
    return res.status(404).json({
      success: false,
      message: 'Transfer not found'
    });
  }

  if (transfer.status !== 'pending') {
    return res.status(400).json({
      success: false,
      message: 'Only pending transfers can be cancelled'
    });
  }

  transfer.status = 'cancelled';
  logger.info(`Transfer ${transfer.transferNumber} cancelled by ${req.user!.username}`);

  res.json({
    success: true,
    message: 'Transfer cancelled successfully'
  });
}));

export default router;
